<?php require_once('Connections/connection.php'); ?>
<?php
if (!function_exists("GetSQLValueString")) {
function GetSQLValueString($theValue, $theType, $theDefinedValue = "", $theNotDefinedValue = "") 
{
  if (PHP_VERSION < 6) {
    $theValue = get_magic_quotes_gpc() ? stripslashes($theValue) : $theValue;
  }

  $theValue = function_exists("mysql_real_escape_string") ? mysql_real_escape_string($theValue) : mysql_escape_string($theValue);

  switch ($theType) {
    case "text":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;    
    case "long":
    case "int":
      $theValue = ($theValue != "") ? intval($theValue) : "NULL";
      break;
    case "double":
      $theValue = ($theValue != "") ? doubleval($theValue) : "NULL";
      break;
    case "date":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;
    case "defined":
      $theValue = ($theValue != "") ? $theDefinedValue : $theNotDefinedValue;
      break;
  }
  return $theValue;
}
}

$editFormAction = $_SERVER['PHP_SELF'];
if (isset($_SERVER['QUERY_STRING'])) {
  $editFormAction .= "?" . htmlentities($_SERVER['QUERY_STRING']);
}

if ((isset($_POST["MM_insert"])) && ($_POST["MM_insert"] == "form2")) {
  $insertSQL = sprintf("INSERT INTO appshop1 (Id_shop, Name, `Data`, `Number`, Picture) VALUES (%s, %s, %s, %s, %s)",
                       GetSQLValueString($_POST['Id_shop'], "text"),
                       GetSQLValueString($_POST['Name'], "text"),
                       GetSQLValueString($_POST['Data'], "text"),
                       GetSQLValueString($_POST['Number'], "int"),
                       GetSQLValueString($_POST['Picture'], "text"));

  mysql_select_db($database_connection, $connection);
  $Result1 = mysql_query($insertSQL, $connection) or die(mysql_error());

  $insertGoTo = "home.php";
  if (isset($_SERVER['QUERY_STRING'])) {
    $insertGoTo .= (strpos($insertGoTo, '?')) ? "&" : "?";
    $insertGoTo .= $_SERVER['QUERY_STRING'];
  }
  header(sprintf("Location: %s", $insertGoTo));
}

if ((isset($_POST["MM_insert"])) && ($_POST["MM_insert"] == "form3")) {
  $insertSQL = sprintf("INSERT INTO appshop1 (Id_shop, Name, `Data`, `Number`, Picture) VALUES (%s, %s, %s, %s, %s)",
                       GetSQLValueString($_POST['Id_shop'], "text"),
                       GetSQLValueString($_POST['Name'], "text"),
                       GetSQLValueString($_POST['Data'], "text"),
                       GetSQLValueString($_POST['Number'], "int"),
                       GetSQLValueString($_POST['Picture'], "text"));

  mysql_select_db($database_connection, $connection);
  $Result1 = mysql_query($insertSQL, $connection) or die(mysql_error());

  $insertGoTo = "home.php";
  if (isset($_SERVER['QUERY_STRING'])) {
    $insertGoTo .= (strpos($insertGoTo, '?')) ? "&" : "?";
    $insertGoTo .= $_SERVER['QUERY_STRING'];
  }
  header(sprintf("Location: %s", $insertGoTo));
}

if ((isset($_POST["MM_insert"])) && ($_POST["MM_insert"] == "form4")) {
  $insertSQL = sprintf("INSERT INTO appshop1 (Id_shop, Name, `Data`, `Number`) VALUES (%s, %s, %s, %s)",
                       GetSQLValueString($_POST['Id_shop'], "text"),
                       GetSQLValueString($_POST['Name'], "text"),
                       GetSQLValueString($_POST['Data'], "text"),
                       GetSQLValueString($_POST['Number'], "int"));

  mysql_select_db($database_connection, $connection);
  $Result1 = mysql_query($insertSQL, $connection) or die(mysql_error());

  $insertGoTo = "home.php";
  if (isset($_SERVER['QUERY_STRING'])) {
    $insertGoTo .= (strpos($insertGoTo, '?')) ? "&" : "?";
    $insertGoTo .= $_SERVER['QUERY_STRING'];
  }
  header(sprintf("Location: %s", $insertGoTo));
}

mysql_select_db($database_connection, $connection);
$query_Recordset1 = "SELECT * FROM appshop1";
$Recordset1 = mysql_query($query_Recordset1, $connection) or die(mysql_error());
$row_Recordset1 = mysql_fetch_assoc($Recordset1);
$totalRows_Recordset1 = mysql_num_rows($Recordset1);
?>
<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->
    <title>เพิ่มข้อมูล</title>

    <!-- Bootstrap -->
    <link href="css/bootstrap.min.css" rel="stylesheet">

    <!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
      <script src="https://oss.maxcdn.com/html5shiv/3.7.3/html5shiv.min.js"></script>
      <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
    <![endif]-->
  <style>
      .switch {
        position: relative;
        display: inline-block;
        width: 60px;
        height: 34px;
      }
      
      .switch input {display:none;}
      
      .slider {
        position: absolute;
        cursor: pointer;
        top: 0;
        left: 0;
        right: 0;
        bottom: 0;
        background-color: #ccc;
        -webkit-transition: .4s;
        transition: .4s;
      }
      
      .slider:before {
        position: absolute;
        content: "";
        height: 26px;
        width: 26px;
        left: 4px;
        bottom: 4px;
        background-color: white;
        -webkit-transition: .4s;
        transition: .4s;
      }
      
      input:checked + .slider {
        background-color: #2196F3;
      }
      
      input:focus + .slider {
        box-shadow: 0 0 1px #2196F3;
      }
      
      input:checked + .slider:before {
        -webkit-transform: translateX(26px);
        -ms-transform: translateX(26px);
        transform: translateX(26px);
      }
      
      /* Rounded sliders */
      .slider.round {
        border-radius: 34px;
      }
      
      .slider.round:before {
        border-radius: 50%;
      }
      </style>
  <link href="SpryAssets/SpryValidationSelect.css" rel="stylesheet" type="text/css">
  <script src="SpryAssets/SpryValidationSelect.js" type="text/javascript"></script>
  </head>
  <body>
    <div class="container text-center">
    <h1>คลังสินค้า</h1>
    </div>
    <a class="navbar-brand" href="#">Logo</a>
  </div>
  <nav class="navbar navbar-inverse">
      <div class="container-fluid">
        <div class="navbar-header">
          <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#myNavbar">
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>                        
          </button>
          <a class="navbar-brand" href="#"></a>
        </div>
        <div class="collapse navbar-collapse" id="myNavbar">
          <ul class="nav navbar-nav">
            <li class="active"><a href="home.php">หน้าหลัก</a></li>
            <li><a href="input.php">เพิ่ม</a></li>
            <li><a href="home1.php">ลบ</a></li>
            <li><a href="#">แก้ไข</a></li>
            
          </ul>
         
        </div>
      </div>
    </nav>
    
    <form name="form1" method="post" action="">
    </form>
    
    <form action="<?php echo $editFormAction; ?>" method="post" enctype="multipart/form-data" name="form2">
      <input type="hidden" name="MM_inser" value="form2">
  </form>
    <form method="post" name="form3" action="<?php echo $editFormAction; ?>">
      <input type="hidden" name="MM_insert" value="form3">
  </form>
    <form method="post" name="form4" action="<?php echo $editFormAction; ?>">
      <table width="624" height="316" align="center">
        <tr valign="baseline">
          <td width="243" align="right" nowrap>รหัสสินค้า:</td>
          <td width="278"><input type="text" name="Id_shop"  class="form-control" value="" size="32"></td>
        </tr>
        <tr valign="baseline">
          <td nowrap align="right">ชื่อสินค้า:</td>
          <td><input type="text" name="Name"  class="form-control" value="" size="32"></td>
        </tr>
        <tr valign="baseline">
          <td nowrap align="right">ข้อมูล:</td>
          <td><input name="Data" type="text"  class="form-control" value="" size="32">
            <span>
            <label for="select1"></label>
            <span class="selectRequiredMsg">Please select an item.</span></span></td>
        </tr>
        <tr valign="baseline">
          <td nowrap align="right">จำนวน:</td>
          <td><input type="text" name="Number"  class="form-control" value="" size="32"></td>
        </tr>
        <tr valign="baseline">
          <td nowrap align="right">&nbsp;</td>
          <td><input type="submit" value="Insert record"></td>
        </tr>
      </table>
      <input type="hidden" name="MM_insert" value="form4">
  </form>
    <p>&nbsp;</p>
<p>&nbsp;</p>
<!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
    <!-- Include all compiled plugins (below), or include individual files as needed -->
  <script src="js/bootstrap.min.js"></script>
   
  <p>&nbsp;</p>
  <script type="text/javascript">
var spryselect1 = new Spry.Widget.ValidationSelect("spryselect1");
  </script>
  </body>
</html>
<?php
mysql_free_result($Recordset1);
?>
